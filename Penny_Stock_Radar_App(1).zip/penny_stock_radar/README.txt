PENNY STOCK RADAR — STARTER PWA

FILES
- index.html: app interface and local watchlist/settings
- manifest.webmanifest: installable app metadata
- sw.js: service worker for offline caching
- icon.svg: app icon

PUBLISH WITH GITHUB PAGES
1. Open your public GitHub repository named penny-stock-radar.
2. Choose Add file > Upload files.
3. Upload all four files from this folder (the files themselves, not the folder).
4. Commit the changes to the main branch.
5. In Settings > Pages, set the source to Deploy from a branch, branch main, folder /(root), then Save.
6. Wait for GitHub Pages to publish, then open:
   https://scottjenchlo-afk.github.io/penny-stock-radar/
7. On Android Chrome, open the site menu (three dots) and choose Install app or Add to Home screen.

IMPORTANT
This is a functional starter app for saving scan settings and a ticker watchlist on the device. It does NOT connect to live market data, verify prices/volume, issue real buy signals, or place trades. A market-data API integration is required for verified current candidates.
